﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCoffeeProject
{
    //Interface
    //When importing in project, I will need to implement a Hello method
    interface IHello
    {
        void Hello();
        
    }
}
